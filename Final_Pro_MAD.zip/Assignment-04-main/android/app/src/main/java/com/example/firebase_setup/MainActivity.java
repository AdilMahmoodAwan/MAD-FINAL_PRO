package com.example.firebase_setup;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
